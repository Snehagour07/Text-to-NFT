import admin from "firebase-admin";
admin.initializeApp();
export default admin;
//import admin pass
