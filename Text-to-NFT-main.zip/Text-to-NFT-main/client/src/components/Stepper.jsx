import React from "react";

const Stepper = () => {
  return <div>Stepper</div>;
};

export default Stepper;
